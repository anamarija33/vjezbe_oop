package pckg_vj10.zd2;

import java.util.EventListener;

public interface FormListener extends EventListener {
    void calculateFormEventOccured(FormEvent event);
    void listFormEventOccured(FormEvent event);
}
