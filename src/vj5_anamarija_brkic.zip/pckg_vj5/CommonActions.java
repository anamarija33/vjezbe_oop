package pckg_vj5;

public interface CommonActions {
   void walk(String s, int n);
   String talk();
   void think(String s);
   int calculate(int n);
   void infoPerson();
}
